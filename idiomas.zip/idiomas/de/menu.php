<?php

return [
    //main menu
    "home" => "Accueil",
    "locations" => "Cantons",
    "contact_us" => "Contactez-nous",
    "register" => "S'inscrire",
    //locations
    'zurich-stadt' => [
        'slug' => 'zuerich-stadt',
        'location' => 'Zürich-Stadt',
        'title' => 'Sex in Zürich-Stadt - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke heiße Sextreffen, geile Sexkontakte und Escorts in Zürich-Stadt! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'zurich' => [
        'slug' => 'zuerich',
        'location' => 'Zürich',
        'title' => 'Sex in Zürich - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe aufregende Sextreffen, knisternde Sexkontakte und verführerische Escorts in Zürich! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'berne' => [
        'slug' => 'bern',
        'location' => 'Bern',
        'title' => 'Sex in Bern - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Genieße leidenschaftliche Sextreffen, sinnliche Sexkontakte und verlockende Escorts in Bern! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'vaud' => [
        'slug' => 'waadt',
        'location' => 'Vaud',
        'title' => 'Sex in Waadt - Sexkontakte und Sextreffen',
        'description' => 'Erlebe heiße Sextreffen, prickelnde Sexkontakte und verführerische Escorts in Waadt! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'aargau' => [
        'slug' => 'aargau',
        'location' => 'Aargau',
        'title' => 'Sex in Aargau - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke aufregende Sextreffen, erotische Sexkontakte und verführerische Escorts in Aargau! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'st-gallen' => [
        'slug' => 'st-gallen',
        'location' => 'St. Gallen',
        'title' => 'Sex in St. Gallen - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe sinnliche Sextreffen, knisternde Sexkontakte und verführerische Escorts in St. Gallen! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'geneve' => [
        'slug' => 'genf',
        'location' => 'Genève',
        'title' => 'Sex in Genf - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke leidenschaftliche Sextreffen, erotische Sexkontakte und verlockende Escorts in Genf! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'luzern' => [
        'slug' => 'luzern',
        'location' => 'Luzern',
        'title' => 'Sex in Luzern - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe heiße Sextreffen, sinnliche Sexkontakte und verführerische Escorts in Luzern! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'tessin' => [
        'slug' => 'Ticino',
        'location' => 'Tessin',
        'title' => 'Sex in Tessin - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke aufregende Sextreffen, erotische Sexkontakte und verführerische Escorts in Tessin! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'valais' => [
        'slug' => 'Valais',
        'location' => 'wallis',
        'title' => 'Sex in Wallis - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe sinnliche Sextreffen, prickelnde Sexkontakte und verlockende Escorts in Wallis! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'fribourg' => [
        'slug' => 'freiburg',
        'location' => 'Fribourg',
        'title' => 'Sex in Freiburg - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke leidenschaftliche Sextreffen, erotische Sexkontakte und verführerische Escorts in Freiburg! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'basel' => [
        'slug' => 'basel-stadt',
        'location' => 'Basel Stadt',
        'title' => 'Sex in Basel-Stadt - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe heiße Sextreffen, sinnliche Sexkontakte und prickelnde Escorts in Basel-Stadt! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'thurgau' => [
        'slug' => 'thurgau',
        'location' => 'Thurgau',
        'title' => 'Sex in Thurgau - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke aufregende Sextreffen, erotische Sexkontakte und verführerische Escorts in Thurgau! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'solothurn' => [
        'slug' => 'solothurn',
        'location' => 'Solothurn',
        'title' => 'Sex in Solothurn - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Erlebe sinnliche Sextreffen, knisternde Sexkontakte und prickelnde Escorts in Solothurn! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
    'basel-land' => [
        'slug' => 'basel-land',
        'location' => 'Basel Land',
        'title' => 'Sex in Basel-Land - Sexkontakte und Sextreffen | figgmi.ch',
        'description' => 'Entdecke leidenschaftliche Sextreffen, erotische Sexkontakte und verlockende Escorts in Basel-Land! Anrufen und geniessen! Das TOP Sex & Erotik Inserate Plattform'
    ],
];

/**
 * Index	de	fr	it
 * aargau	aargau	aarau	argovia
 * basel	basel	basel	basilea
 * bern	bern	berne	berna
 * fribourg	freiburg	fribourg	friburgo
 * geneve	genf	geneve	ginevra
 * luzern	luzern	lucerne	lucerna
 * solothurn	solothurn	soleure	soletta
 * st-gallen	st-gallen	saint-gall	san-gallo
 * thurgau 	thurgau	thurgovie	thurgovia
 * ticino	tessin	tessin	ticino
 * valais	wallis	valais	vallese
 * vaud	waadt	vaud	vaud
 * zurich	zurich	zurich	zurigo
 */